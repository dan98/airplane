%constants
close all
clc
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0.5 0.5 0.75 0.75]);
m=4;%mass
J=0.0475;%intertia
r=0.25;%thrust offset
g=9.8;%gravitational constant
c=0.05;%rotatioinal damping

A=[0,0,0,1,0,0;
    0,0,0,0,1,0;
    0,0,0,0,0,1;
    0,0,-g,-c/m,0,0;
    0,0,0,0,-c/m,0;
    0,0,0,0,0,0];

B=[0,0;
    0,0;
    0,0;
    1/m,0;
    0,1/m;
    r/J,0];


% x_0, y_0, th_0, xd_0, yd_0, thd_0

% Initial conditions
sys0 = [5; -5; pi; 0; 0; 0];
obs0 = [0; 0; 0; 0; 0; 0];

z0 = [sys0; obs0];

C = zeros(6);
C(1,1) = 1;
C(2,2) = 1;
C(3,3) = 1;

%this part finds a stabilizing feedback controller

%try these eigenvalues;
p = -randperm(6)*0.1 - [1,1,1,1,1,1];
p

F = -place(A,B,p);
G = -place(A',-C',p);

G=G';
eig(A-G*C)

l = cell(1,3);
l{1}='Real State'; l{2}='Observer'; l{3}='Error';


[t, zt] = ode45(@(t, z) linodefun(t, z, A, B, C, F, G), [0 10], z0);

inputs = F*zt(:, 1:6)';
mini = min(min(inputs));
maxi = max(max(inputs));

asizes = [-50,50,-50,50];

lwing = [-5; 0];
rwing = [0; 5];


for i = 1:length(t)
	syst = zt(i, 1:6)';
	obst = zt(i, 7:12)';

    output=C*syst;

    x = output(1);
    y = output(2);
	theta = output(3);

    Q=[syst obst abs(obst - syst)];
    subplot(2,2,1);

	input = F*syst;

    %h = bar(categorical({'x','y','theta','xdot','ydot','thetadot'}),Q);
    %ylim([min(min(Q)) max(max(Q))]);
    %legend(h,l);

    h = bar(categorical({'F_1','F_2'}),input);
    ylim([mini maxi]);

	
    subplot(2,2,2);
    plot(x,y,'or','MarkerSize',20,'MarkerFaceColor','b');
	hold on;

	rot = exp(-(theta)*1i);

	plot(real(lwing*rot) + x, imag(lwing*rot) + y, 'LineWidth', 5);
	plot(real(rwing*rot) + x, imag(rwing*rot) + y, 'LineWidth', 5);
	hold off;

    axis(asizes);% can change these

	subplot(2,2,3);
	plot(t, zt(:, 1));
	hold on;
	scatter(t(i), zt(i,1));
	hold off;

	subplot(2,2,4);
	plot(t, zt(:, 2));
	hold on;
	scatter(t(i), zt(i,2));
	hold off;

    drawnow;
end


close all
    
