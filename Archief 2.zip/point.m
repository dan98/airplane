function [arr] = point(z)
	arr = [real(z); imag(z)];
end
